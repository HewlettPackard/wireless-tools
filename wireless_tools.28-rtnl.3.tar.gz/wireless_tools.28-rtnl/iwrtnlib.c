/*
 *	Wireless Tools
 *
 *		Jean II - HPL 99->06
 *
 * Test code for RtNetlink
 *
 * This file is released under the GPL license.
 *     Copyright (c) 1997-2006 Jean Tourrilhes <jt@hpl.hp.com>
 */

/***************************** INCLUDES *****************************/

#include "iwlib.h"		/* Header */

#include "libnetlink.h"		/* Netlink library */

#include <getopt.h>
#include <time.h>
#include <sys/time.h>

/************************** DOCUMENTATION **************************/
/*
 * This file is only a proof of concept for how to use RtNetlink
 * and only useful for debugging RtNetlink.
 * It's complex because we try to be generic and transparent to the
 * rest of the W-Tools code. Code directly designed on top of
 * RtNetlink would be much simpler (as can be seen in the iwpriv
 * implementation).
 *
 * Jean II
 */

/*
 * Test suite :

iwgetid eth1 --freq
iwgetid eth1
iwconfig eth1 rate 2M
iwconfig eth1 essid "toto"
iwconfig eth1 nick "toto"
iwconfig eth1 mode managed essid any
iwconfig eth1 mode ad-hco essid MY_NETWORK
iwconfig eth1 nwid 01
iwpriv
iwlist eth1 freq
iwlist eth1 scan
iwpriv eth0 get_port3
iwpriv eth0 set_port3 1
iwpriv eth0 get_stuff
iwpriv eth0 get_stuff
iwpriv eth0 set_stuff toto

 * This gives full coverage of the RtNetlink API...
 */


/**************************** CONSTANTS ****************************/

//#define WE_DEBUG	1

/* Flags available in struct iw_request_info */
#define IW_REQUEST_FLAG_NONE	0x0000	/* No flag so far */

/* Type of headers we know about (basically union iwreq_data) */
#define IW_HEADER_TYPE_NULL	0	/* Not available */
#define IW_HEADER_TYPE_CHAR	2	/* char [IFNAMSIZ] */
#define IW_HEADER_TYPE_UINT	4	/* __u32 */
#define IW_HEADER_TYPE_FREQ	5	/* struct iw_freq */
#define IW_HEADER_TYPE_ADDR	6	/* struct sockaddr */
#define IW_HEADER_TYPE_POINT	8	/* struct iw_point */
#define IW_HEADER_TYPE_PARAM	9	/* struct iw_param */
#define IW_HEADER_TYPE_QUAL	10	/* struct iw_quality */

/* Handling flags */
/* Most are not implemented. I just use them as a reminder of some
 * cool features we might need one day ;-) */
#define IW_DESCR_FLAG_NONE	0x0000	/* Obvious */
/* Wrapper level flags */
#define IW_DESCR_FLAG_DUMP	0x0001	/* Not part of the dump command */
#define IW_DESCR_FLAG_EVENT	0x0002	/* Generate an event on SET */
#define IW_DESCR_FLAG_RESTRICT	0x0004	/* GET : request is ROOT only */
				/* SET : Omit payload from generated iwevent */
#define IW_DESCR_FLAG_NOMAX	0x0008	/* GET : no limit on request size */
/* Driver level flags */
#define IW_DESCR_FLAG_WAIT	0x0100	/* Wait for driver event */

/* Forward compatibility */
#define IW_EV_POINT_OFF (((char *) &(((struct iw_point *) NULL)->length)) - \
			  (char *) NULL)

/****************************** TYPES ******************************/

/*
 * Describe how a standard IOCTL looks like.
 */
struct iw_ioctl_description
{
	__u8	header_type;		/* NULL, iw_point or other */
	__u8	token_type;		/* Future */
	__u16	token_size;		/* Granularity of payload */
	__u16	min_tokens;		/* Min acceptable token number */
	__u16	max_tokens;		/* Max acceptable token number */
	__u32	flags;			/* Special handling of the request */
};

struct iw_rtn_reply
{
  char *	buffer;		/* Buffer to hold the reply */
  int		buflen;		/* Size of buffer */
  char *	hdr;		/* Reply header */
  int		hdr_len;	/* Size of the reply header */
  int		offset;		/* Offset to deal with struct iw_point */
  char *	extra;		/* Extra space in case of struct iw_point */
  int		extra_len;	/* Size of extra space */
};

/**************************** PROTOTYPES ****************************/

static int
	iw_get_ifindex(int		skfd,	/* Socket to the kernel */
		       const char *	ifname);

/************************* GLOBAL VARIABLES *************************/
/*
 * You should not use global variables, because of re-entrancy.
 * Too bad...
 */

/*
 * Meta-data about all the standard Wireless Extension request we
 * know about.
 */
static const struct iw_ioctl_description	standard_ioctl[] = {
	/* SIOCSIWCOMMIT */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCGIWNAME */
	{ IW_HEADER_TYPE_CHAR, 0, 0, 0, 0, IW_DESCR_FLAG_DUMP},
	/* SIOCSIWNWID */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, IW_DESCR_FLAG_EVENT},
	/* SIOCGIWNWID */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, IW_DESCR_FLAG_DUMP},
	/* SIOCSIWFREQ */
	{ IW_HEADER_TYPE_FREQ, 0, 0, 0, 0, IW_DESCR_FLAG_EVENT},
	/* SIOCGIWFREQ */
	{ IW_HEADER_TYPE_FREQ, 0, 0, 0, 0, IW_DESCR_FLAG_DUMP},
	/* SIOCSIWMODE */
	{ IW_HEADER_TYPE_UINT, 0, 0, 0, 0, IW_DESCR_FLAG_EVENT},
	/* SIOCGIWMODE */
	{ IW_HEADER_TYPE_UINT, 0, 0, 0, 0, IW_DESCR_FLAG_DUMP},
	/* SIOCSIWSENS */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWSENS */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWRANGE */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCGIWRANGE */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, sizeof(struct iw_range), IW_DESCR_FLAG_DUMP | IW_DESCR_FLAG_NOMAX},
	/* SIOCSIWPRIV */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCGIWPRIV */
	{ IW_HEADER_TYPE_POINT, 0, sizeof(struct iw_priv_args), 0, 16, IW_DESCR_FLAG_NOMAX},
	/* SIOCSIWSTATS */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCGIWSTATS */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, sizeof(struct iw_statistics), IW_DESCR_FLAG_DUMP},
	/* SIOCSIWSPY */
	{ IW_HEADER_TYPE_POINT, 0, sizeof(struct sockaddr), 0, IW_MAX_SPY, 0},
	/* SIOCGIWSPY */
	{ IW_HEADER_TYPE_POINT, 0, (sizeof(struct sockaddr) + sizeof(struct iw_quality)), 0, IW_MAX_SPY, 0},
	/* SIOCSIWTHRSPY */
	{ IW_HEADER_TYPE_POINT, 0, sizeof(struct iw_thrspy), 1, 1, 0},
	/* SIOCGIWTHRSPY */
	{ IW_HEADER_TYPE_POINT, 0, sizeof(struct iw_thrspy), 1, 1, 0},
	/* SIOCSIWAP */
	{ IW_HEADER_TYPE_ADDR, 0, 0, 0, 0, 0},
	/* SIOCGIWAP */
	{ IW_HEADER_TYPE_ADDR, 0, 0, 0, 0, IW_DESCR_FLAG_DUMP},
	/* -- hole -- */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCGIWAPLIST */
	{ IW_HEADER_TYPE_POINT, 0, (sizeof(struct sockaddr) + sizeof(struct iw_quality)), 0, IW_MAX_AP, IW_DESCR_FLAG_NOMAX},
	/* SIOCSIWSCAN */
	{ IW_HEADER_TYPE_POINT, 0, 0, 0, 0, 0},
	/* SIOCGIWSCAN */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_SCAN_MAX_DATA, IW_DESCR_FLAG_NOMAX},
	/* SIOCSIWESSID */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ESSID_MAX_SIZE + 1, IW_DESCR_FLAG_EVENT},
	/* SIOCGIWESSID */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ESSID_MAX_SIZE + 1, IW_DESCR_FLAG_DUMP},
	/* SIOCSIWNICKN */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ESSID_MAX_SIZE + 1, 0},
	/* SIOCGIWNICKN */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ESSID_MAX_SIZE + 1, 0},
	/* -- hole -- */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* -- hole -- */
	{ IW_HEADER_TYPE_NULL, 0, 0, 0, 0, 0},
	/* SIOCSIWRATE */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWRATE */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWRTS */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWRTS */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWFRAG */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWFRAG */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWTXPOW */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWTXPOW */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWRETRY */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWRETRY */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCSIWENCODE */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ENCODING_TOKEN_MAX, IW_DESCR_FLAG_EVENT | IW_DESCR_FLAG_RESTRICT},
	/* SIOCGIWENCODE */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_ENCODING_TOKEN_MAX, IW_DESCR_FLAG_DUMP | IW_DESCR_FLAG_RESTRICT},
	/* SIOCSIWPOWER */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
	/* SIOCGIWPOWER */
	{ IW_HEADER_TYPE_PARAM, 0, 0, 0, 0, 0},
};
static const int standard_ioctl_num = (sizeof(standard_ioctl) /
				       sizeof(struct iw_ioctl_description));

/*
 * Meta-data about all the additional standard Wireless Extension events
 * we know about.
 */
static const struct iw_ioctl_description	standard_event[] = {
	/* IWEVTXDROP */
	{ IW_HEADER_TYPE_ADDR, 0, 0, 0, 0, 0},
	/* IWEVQUAL */
	{ IW_HEADER_TYPE_QUAL, 0, 0, 0, 0, 0},
	/* IWEVCUSTOM */
	{ IW_HEADER_TYPE_POINT, 0, 1, 0, IW_CUSTOM_MAX, 0},
	/* IWEVREGISTERED */
	{ IW_HEADER_TYPE_ADDR, 0, 0, 0, 0, 0},
	/* IWEVEXPIRED */
	{ IW_HEADER_TYPE_ADDR, 0, 0, 0, 0, 0},
};
static const int standard_event_num = (sizeof(standard_event) /
				       sizeof(struct iw_ioctl_description));

/* Size (in bytes) of the various private data types */
static const char priv_type_size[] = {
	0,				/* IW_PRIV_TYPE_NONE */
	1,				/* IW_PRIV_TYPE_BYTE */
	1,				/* IW_PRIV_TYPE_CHAR */
	0,				/* Not defined */
	sizeof(__u32),			/* IW_PRIV_TYPE_INT */
	sizeof(struct iw_freq),		/* IW_PRIV_TYPE_FLOAT */
	sizeof(struct sockaddr),	/* IW_PRIV_TYPE_ADDR */
	0,				/* Not defined */
};

/* Size (in bytes) of various events */
static const int event_type_size[] = {
	IW_EV_LCP_LEN,		/* IW_HEADER_TYPE_NULL */
	0,
	IW_EV_CHAR_LEN,		/* IW_HEADER_TYPE_CHAR */
	0,
	IW_EV_UINT_LEN,		/* IW_HEADER_TYPE_UINT */
	IW_EV_FREQ_LEN,		/* IW_HEADER_TYPE_FREQ */
	IW_EV_ADDR_LEN,		/* IW_HEADER_TYPE_ADDR */
	0,
	IW_EV_POINT_LEN,	/* Without variable payload */
	IW_EV_PARAM_LEN,	/* IW_HEADER_TYPE_PARAM */
	IW_EV_QUAL_LEN,		/* IW_HEADER_TYPE_QUAL */
};

/*------------------------------------------------------------------*/

static struct rtnl_handle	iw_rth;


/******************* WIRELESS REQUESTS PROCESSING *******************/
/*
 * 
 */

/* ---------------------------------------------------------------- */
/*
 * Extract Wireless reply from RtNEtlink reply
 */
static int
iw_rtnetlink_extract_reply(struct nlmsghdr *		nlh,
			   struct iw_rtn_reply *	reply)
{
  struct ifinfomsg* ifi;
  ifi = NLMSG_DATA(nlh);

#ifdef WE_DEBUG
  printf("Got reply !\n");
#endif	/* WE_DEBUG */

  /* Check for attributes */
  if (nlh->nlmsg_len > NLMSG_ALIGN(sizeof(struct ifinfomsg)))
    {
      int attrlen = nlh->nlmsg_len - NLMSG_ALIGN(sizeof(struct ifinfomsg));
      struct rtattr *attr = IFLA_RTA(ifi);

      while (RTA_OK(attr, attrlen))
	{
#ifdef WE_DEBUG
	  printf("Got attribute : len=%d, type=%d!\n", attrlen, attr->rta_type);
#endif	/* WE_DEBUG */

	  /* Check if the Wireless kind */
	  if(attr->rta_type == IFLA_WIRELESS)
	    {
	      int	rta_len = attr->rta_len - RTA_ALIGN(sizeof(struct rtattr));

#ifdef WE_DEBUG
	      printf("Got wireless (%d bytes) !\n", rta_len);
#endif	/* WE_DEBUG */

	      if(reply->extra_len <= 0)
		{
		  /* No extra, check length */
		  if(rta_len != reply->hdr_len)
		    {
#ifdef WE_DEBUG
		      fprintf(stderr, "Invalid reply length (%d != %d)\n",
			      rta_len, reply->hdr_len);
#endif	/* WE_DEBUG */
		      errno = EINVAL;
		      return(-1);
		    }
		}
	      else
		{
		  /* With extra, check length */
		  if(rta_len < reply->hdr_len)
		    {
#ifdef WE_DEBUG
		      fprintf(stderr, "Reply too short (%d < %d)\n",
			      rta_len, reply->hdr_len);
#endif	/* WE_DEBUG */
		      errno = EINVAL;
		      return(-1);
		    }
		  if(rta_len > (reply->hdr_len + reply->extra_len))
		    {
#ifdef WE_DEBUG
		      fprintf(stderr, "Reply too big (%d > %d)\n",
			      rta_len, reply->hdr_len + reply->extra_len);
#endif	/* WE_DEBUG */
		      errno = E2BIG;
		      return(-1);
		    }

		  /* Link extra */
		  reply->extra = (char *)attr + RTA_ALIGN(sizeof(struct rtattr)) + reply->hdr_len;
		}

	      /* Link event header */
	      reply->hdr = (char *)attr + RTA_ALIGN(sizeof(struct rtattr));

	      /* Done */
	      return 0;
	    }

	  /* Next attribute */
	  attr = RTA_NEXT(attr, attrlen);
	}
    }
  return -1;
}

/* ---------------------------------------------------------------- */
/*
 * Send a RtNetlink request
 */
static int
iw_rtnetlink_send(struct rtnl_handle *	rth,
		  int			ifindex,
		  char *		request,
		  int			request_len,
		  int			is_set,
		  struct iw_rtn_reply *	reply)
{
  char *		buffer;
  int			buflen;
  int			nlmsize;
  int			rtasize;
  struct nlmsghdr *	nlh;
  struct ifinfomsg *	ifi;
  int			ret;

  /* Size of the whole request */
  nlmsize = NLMSG_LENGTH(sizeof(struct ifinfomsg));
  rtasize = RTA_SPACE(request_len);
  buflen = nlmsize + rtasize;

  /* Allocate & zero */
  buffer = calloc(1, buflen);

  /* Get pointers to buffer */
  nlh = (struct nlmsghdr *) buffer;
  ifi = NLMSG_DATA(nlh);

  nlh->nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
  nlh->nlmsg_flags = NLM_F_REQUEST;

  /* Which interface is it ? */
  if(ifindex == -1)
    {
      fprintf(stderr, "%s: error, ifindex == -1\n", __FUNCTION__);
      return(-1);
    }
  ifi->ifi_index = ifindex;

  ifi->ifi_family = AF_UNSPEC;
  // Those are not used
  //ifi->ifi_type = 0;
  //ifi->ifi_flags = 0;
  //ifi->ifi_change = 0;

  /* Add request in the RtNetlink message */
  addattr_l(nlh, buflen, IFLA_WIRELESS, request, request_len);
#ifdef WE_DEBUG
  fprintf(stderr, "Sending RtNetlink request len %d\n", nlh->nlmsg_len);
#endif	/* WE_DEBUG */

  /* Send it !!! */
  if(is_set)
    {
      nlh->nlmsg_type = RTM_SETLINK;
      ret = rtnl_talk(rth, nlh, 0, 0, NULL, NULL, NULL);
    }
  else
    {
      struct nlmsghdr *	nlh_reply;

      /* Stupid limits in libnetlink */
      reply->buflen = nlmsize + RTA_SPACE(reply->hdr_len + reply->extra_len);
      reply->buffer = malloc(reply->buflen);
      if(reply->buffer == NULL)
	return(-1);
      nlh_reply = (struct nlmsghdr *) reply->buffer;

      nlh->nlmsg_type = RTM_GETLINK;
      ret = rtnl_talk(rth, nlh, 0, 0, nlh_reply, NULL, NULL);

      if(ret >= 0)
	ret = iw_rtnetlink_extract_reply(nlh_reply, reply);
    }
  /* Check what happend */
  if(ret < 0)
    {
#ifdef WE_DEBUG
      fprintf(stderr, "%s: Error sending RtNetlink request: %s\n",
	      __FUNCTION__, strerror(errno));
#endif	/* WE_DEBUG */
      return(-1);
    }

  return(0);
}

/* ---------------------------------------------------------------- */
/*
 * Create a wireless request
 */
static struct iw_event  *
iw_create_request(unsigned int		cmd,
		  union iwreq_data *	wrqu)
{
  const struct iw_ioctl_description *	descr = NULL;
  struct iw_event  *request;		/* Mallocated whole request */
  int		request_len;		/* Its size */
  int		hdr_len;		/* Size of the request header */
  char *	extra = NULL;		/* Extra data */
  int		extra_len = 0;
  /* Don't "optimise" the following variable, it will crash */
  unsigned	cmd_index;		/* *MUST* be unsigned */

  /* Get the description of the Request */
  if(cmd <= SIOCIWLAST)
    {
      cmd_index = cmd - SIOCIWFIRST;
      if(cmd_index < (unsigned) standard_ioctl_num)
	descr = &(standard_ioctl[cmd_index]);
    }
  /* Don't accept unknown requests */
  if(descr == NULL)
    {
#ifdef WE_DEBUG
      fprintf(stderr, "Invalid/Unknown Wireless Request (0x%04X)\n", cmd);
#endif	/* WE_DEBUG */
      errno = EOPNOTSUPP;
      return(NULL);
    }

#ifdef WE_DEBUG
  fprintf(stderr, "Creating request 0x%04X\n", cmd);
  fprintf(stderr, "Header type : %d, Token type : %d, size : %d, token : %d\n",
	  descr->header_type, descr->token_type, descr->token_size, descr->max_tokens);
#endif	/* WE_DEBUG */

  /* Check extra parameters and set extra_len */
  if(IW_IS_SET(cmd) && (descr->header_type == IW_HEADER_TYPE_POINT))
    {
      extra = wrqu->data.pointer;
      extra_len = wrqu->data.length * descr->token_size;

#ifdef WE_DEBUG
      /* Check if number of token fits within bounds */
      if(wrqu->data.length > descr->max_tokens)
	{
	  fprintf(stderr, "Wireless Request too big (%d)\n",
		  wrqu->data.length);
	  errno = E2BIG;
	  return(NULL);
	}
      if(wrqu->data.length < descr->min_tokens)
	{
	  fprintf(stderr, "Wireless Request too small (%d)\n",
		  wrqu->data.length);
	  errno = EINVAL;
	  return(NULL);
	}
      fprintf(stderr, "Request 0x%04X, tokens %d, extra_len %d\n",
	      cmd, wrqu->data.length, extra_len);
#endif	/* WE_DEBUG */
    }

  /* Total length of the request */
  hdr_len = event_type_size[descr->header_type];
  request_len = hdr_len + extra_len;

#ifdef WE_DEBUG
  fprintf(stderr, "Request 0x%04X, hdr_len %d, request_len %d\n",
	 cmd, hdr_len, request_len);
#endif	/* WE_DEBUG */

  /* Create temporary buffer to hold the full request */
  request = malloc(request_len);
  if(request == NULL)
    {
      errno = ENOMEM;
      return(NULL);
    }

  /* Fill request from the various bits */
  request->len = request_len;
  request->cmd = cmd;
  if(descr->header_type == IW_HEADER_TYPE_POINT)
    memcpy(&request->u, ((char *) wrqu) + IW_EV_POINT_OFF,
	   hdr_len - IW_EV_LCP_LEN);
  else
    memcpy(&request->u, wrqu, hdr_len - IW_EV_LCP_LEN);
  if(extra != NULL)
    memcpy(((char *) request) + hdr_len, extra, extra_len);

  /* Return to caller */
  return(request);
}

/* ---------------------------------------------------------------- */
/*
 * Calculate size of the reply
 */
static int
iw_sizeof_reply(unsigned int		cmd,
		union iwreq_data *	wrqu,
		struct iw_rtn_reply *	reply)
{
  const struct iw_ioctl_description *	descr = NULL;
  int		reply_len;		/* Its size */
  /* Don't "optimise" the following variable, it will crash */
  unsigned	cmd_index;		/* *MUST* be unsigned */

  /* Clear up the reply struct, zero pointer (esp. buffer) */
  memset(reply, '\0', sizeof(struct iw_rtn_reply));

  /* Get the description of the Reply */
  if(cmd <= SIOCIWLAST)
    {
      cmd_index = cmd - SIOCIWFIRST;
      if(cmd_index < (unsigned) standard_ioctl_num)
	descr = &(standard_ioctl[cmd_index]);
    }
  /* Don't accept unknown replys */
  if(descr == NULL)
    {
#ifdef WE_DEBUG
      fprintf(stderr, "Invalid/Unknown Wireless Request (0x%04X)\n", cmd);
#endif	/* WE_DEBUG */
      errno = EOPNOTSUPP;
      return(-1);
    }

  /* Check extra parameters and set extra_len */
  if(IW_IS_GET(cmd) && (descr->header_type == IW_HEADER_TYPE_POINT))
    {
      /* Calculate extra_len */
      reply->extra_len = descr->max_tokens * descr->token_size;
      /* Support for very large requests */
      if((descr->flags & IW_DESCR_FLAG_NOMAX) &&
	 (wrqu->data.length  > descr->max_tokens))
	reply->extra_len = wrqu->data.length * descr->token_size;
      /* Make sure extra get to the right place */
      reply->extra = wrqu->data.pointer;
    }
  else
    {
      /* No extra */
      reply->extra_len = 0;
      reply->extra = NULL;
    }

  /* Total length of the reply */
  reply->hdr_len = event_type_size[descr->header_type];
  reply->hdr = NULL;
  reply_len = reply->hdr_len + reply->extra_len;

#ifdef WE_DEBUG
  fprintf(stderr, "Reply 0x%04X, hdr_len %d, extra_len %d, reply_len %d\n",
	  cmd, reply->hdr_len, reply->extra_len, reply_len);
#endif	/* WE_DEBUG */

  /* Return to caller */
  return(reply_len);
}

/* ---------------------------------------------------------------- */
/*
 * Calculate size of the reply
 */
static int
iw_copy_reply(unsigned int		cmd,
	      union iwreq_data *	wrqu,
	      struct iw_rtn_reply *	reply)
{
  const struct iw_ioctl_description *	descr = NULL;
  struct iw_event  *	event;
  /* Don't "optimise" the following variable, it will crash */
  unsigned	cmd_index;		/* *MUST* be unsigned */

  /* Get the description of the Reply */
  if(cmd <= SIOCIWLAST)
    {
      cmd_index = cmd - SIOCIWFIRST;
      if(cmd_index < (unsigned) standard_ioctl_num)
	descr = &(standard_ioctl[cmd_index]);
    }
  /* Don't accept unknown replys */
  if(descr == NULL)
    {
#ifdef WE_DEBUG
      fprintf(stderr, "Invalid/Unknown Wireless Request (0x%04X)\n", cmd);
#endif	/* WE_DEBUG */
      errno = EOPNOTSUPP;
      return(-1);
    }

  /* Point to the right place */
  event = (struct iw_event  *) reply->hdr;

#ifdef WE_DEBUG
  /* Make sure the reply is the right one */
  if(event->cmd != cmd)
    {
      fprintf(stderr, "Mismatched reply (0x%04X != 0x%04X)\n",
	      event->cmd, cmd);
      errno = EPROTO;
      return(-1);
    }
#endif	/* WE_DEBUG */

  /* Check for pointer types */
  if(descr->header_type == IW_HEADER_TYPE_POINT)
    {
      /* Don't touch the pointer */
      memcpy(((char *) wrqu) + IW_EV_POINT_OFF,
	     &(event->u), IW_EV_POINT_LEN);

      /* Copy to user buffer */
      memcpy(wrqu->data.pointer, reply->extra, reply->extra_len);
    }
  else
    {
#ifdef WE_DEBUG
      /* Verify size */
      if(event->len != reply->hdr_len)
	{
	  fprintf(stderr, "Invalid header length (%d != %d)\n",
		  event->len, reply->hdr_len);
	  errno = EINVAL;
	  return(-1);
	}
#endif	/* WE_DEBUG */

      /* Non pointer types. Just copy the whole thing */
      memcpy(wrqu, &(event->u), reply->hdr_len - IW_EV_LCP_LEN);
    }

  /* Return to caller */
  return(0);
}

/**************************** MAIN CALLS ****************************/

/*------------------------------------------------------------------*/
/*
 * Push/Extract some Wireless Parameter in the driver using RtNetlink
 * The reason why this is so complex is because we try to be generic
 * and pretend to the rest of the code we are an ioctl. And also
 * we don't many consistency check that may not be needed.
 * Jean II
 */
static int
iw_rtnetlink_do(struct rtnl_handle *	rth,		/* RtNetlink socket */
		int			ifindex,	/* Device index */
		int			cmd,		/* WE ID */
		union iwreq_data *	wrqu)		/* Request */
{
  struct iw_event  *	request;
  struct iw_rtn_reply	reply;
  int			ret;

  /* Set-up reply */
  ret = iw_sizeof_reply(cmd, wrqu, &reply);
  if(ret < 0)
    return(-1);

  /* Create request */
  request = iw_create_request(cmd, wrqu);
  if(!request)
    return(-1);

  /* Send it */
  ret = iw_rtnetlink_send(rth, ifindex, (char *) request, request->len,
			  IW_IS_SET(cmd), &reply);
  free(request);
  if(ret)
    goto out;

  /* Push reply back to caller */
  if(IW_IS_GET(cmd))
    ret = iw_copy_reply(cmd, wrqu, &reply);

 out:
  /* Cleanup */
  if(reply.buffer)
    free(reply.buffer);

  return(ret);
}

/*------------------------------------------------------------------*/
/*
 * Push/Extract some Private Wireless Parameter in the driver using RtNetlink
 * For private, things are more complex. As the caller has all
 * the right info, ask him to pass that to us. As there is only one
 * user in iwpriv, we don't really need to be transparent...
 * Which leads to a simpler implementation in here...
 */
int
iw_rtnetlink_do_priv(int		skfd,		/* Socket for ioctl */
		     const char *	ifname,		/* Device name */
		     int		cmd,		/* WE ID */
		     struct iwreq *	pwrq,		/* Fixed part */
		     int		set_size,
		     int		get_size,
		     char *		extra)
{
  int			ifindex;
  union iwreq_data *	wrqu = &(pwrq->u);
  struct iw_event  *	request;
  int			request_len;	/* Its size */
  int			req_hdr_len;	/* Size of the request header */
  int			req_extra_len;
  struct iw_rtn_reply	reply;
  int			ret;

  /* Get interface index */
  ifindex = iw_get_ifindex(skfd, ifname);
  if(ifindex < 0)
    return(-1);

  /* Clear up the reply struct, zero pointer (esp. buffer) */
  memset(&reply, '\0', sizeof(struct iw_rtn_reply));

  /* Check for extra */
  if(extra)
    {
      /* Always use a iw_point header */
      req_hdr_len = IW_EV_POINT_LEN;
      reply.hdr_len = IW_EV_POINT_LEN;
      reply.hdr = NULL;
      /* Where do extra go ? */
      if(set_size)
	{
	  /* We have some extra to push */
	  req_extra_len = set_size;
	  /* No extra in reply */
	  reply.extra_len = 0;
	  reply.extra = NULL;
	}
      else
	{
	  req_extra_len = 0;
	  /* We have an extra reply */
	  reply.extra_len = get_size;
	  reply.extra = extra;
	}
    }
  else
    {
      /* Where the data go ? */
      req_hdr_len = set_size + IW_EV_LCP_LEN;
      reply.hdr_len = get_size + IW_EV_LCP_LEN;
      if(get_size && get_size > set_size)
	/* Kernel expect to receive a complete wrqu */
	req_hdr_len = get_size + IW_EV_LCP_LEN;
      else
      reply.hdr = NULL;
      /* No extra */
      req_extra_len = 0;
      reply.extra_len = 0;
      reply.extra = NULL;
    }

  /* Create the request */
  request_len = req_hdr_len + req_extra_len;

#ifdef WE_DEBUG
  fprintf(stderr, "Request 0x%04X, hdr_len %d, extra_len %d, request_len %d\n",
	  cmd, req_hdr_len, req_extra_len, request_len);
  fprintf(stderr, "Reply 0x%04X, hdr_len %d, extra_len %d, reply_len %d\n",
	  cmd, reply.hdr_len, reply.extra_len,
	  reply.hdr_len + reply.extra_len);
#endif	/* WE_DEBUG */

  /* Create temporary buffer to hold the full request */
  request = malloc(request_len);
  if(request == NULL)
    {
      errno = ENOMEM;
      return(-1);
    }
  /* Fill request from the various bits */
  request->len = request_len;
  request->cmd = cmd;
  if(req_extra_len)
    {
      memcpy(&request->u, ((char *) wrqu) + IW_EV_POINT_OFF,
	     req_hdr_len - IW_EV_LCP_LEN);
      memcpy(((char *) request) + req_hdr_len, extra, req_extra_len);
    }
  else
    memcpy(&request->u, wrqu, req_hdr_len - IW_EV_LCP_LEN);

  /* Send it */
  ret = iw_rtnetlink_send(&iw_rth, ifindex, (char *) request, request->len,
			  IW_IS_SET(cmd), &reply);
  free(request);
  if(ret)
    goto out;

  /* Push reply back to caller */
  if(get_size)
    {
      if(reply.extra_len)
	{
	  struct iw_event  *	event = (struct iw_event  *) reply.hdr;

	  /* Don't touch the pointer */
	  memcpy(((char *) wrqu) + IW_EV_POINT_OFF,
		 &(event->u), IW_EV_POINT_LEN);

	  /* Copy to user buffer */
	  memcpy(wrqu->data.pointer, reply.extra, reply.extra_len);
	}
      else
	{
	  struct iw_event  *	event = (struct iw_event  *) reply.hdr;
 
#ifdef WE_DEBUG
	  /* Verify size */
	  if(event->len != reply.hdr_len)
	    {
	      fprintf(stderr, "Invalid header length (%d != %d)\n",
		      event->len, reply.hdr_len);
	      errno = EINVAL;
	      ret = -1;
	      goto out;
	    }
#endif	/* WE_DEBUG */

	  /* Non pointer types. Just copy the whole thing */
	  memcpy(wrqu, &(event->u), reply.hdr_len - IW_EV_LCP_LEN);
	}
    }

 out:
  /* Cleanup */
  if(reply.buffer)
    free(reply.buffer);

  return(ret);
}

/********************** BACKWARD COMPATIBILITY **********************/

/*------------------------------------------------------------------*/
/*
 * Open RtNetlink channel
 */
int
iw_rtnetlink_open(void)
{
  /* Open netlink channel */
  if(rtnl_open(&iw_rth, RTMGRP_LINK) < 0)
    {
      perror("Can't initialize rtnetlink socket");
      return(-1);
    }
  return(0);
}

/*------------------------------------------------------------------*/
/*
 * Close RtNetlink channel
 */
void
iw_rtnetlink_close(void)
{
  /* Close netlink channel */
  rtnl_close(&iw_rth);
}

/* ---------------------------------------------------------------- */
/*
 * Get interface index
 *
 * Most functions around here use the interface index, not the
 * interface name. This convert interface name into interface
 * index.
 */
static int
iw_get_ifindex(int		skfd,		/* Socket to the kernel */
	       const char *	ifname)
{
  struct ifreq ifr;

  ifr.ifr_ifindex = -1;
  if(ifname)
    {
      strncpy(ifr.ifr_name, ifname, IFNAMSIZ); 
      if(ioctl(skfd, SIOCGIFINDEX, &ifr) < 0)
	{
	  fprintf(stderr, "ioctl(SIOCGIFINDEX) : %s\n", strerror(errno));
	  return(-1);
	}
    }
  return(ifr.ifr_ifindex);
}

/*------------------------------------------------------------------*/
/*
 * Wrapper to push some Wireless Parameter in the driver
 */
int
iw_set_ext(int			skfd,		/* Socket to the kernel */
	   const char *		ifname,		/* Device name */
	   int			request,	/* WE ID */
	   struct iwreq *	pwrq)		/* Fixed part of the request */
{
  int	ifindex = iw_get_ifindex(skfd, ifname);
  if(ifindex < 0)
    return(-1);
  return(iw_rtnetlink_do(&iw_rth, ifindex, request, &(pwrq->u)));
}

/*------------------------------------------------------------------*/
/*
 * Wrapper to extract some Wireless Parameter out of the driver
 */
int
iw_get_ext(int			skfd,		/* Socket to the kernel */
	   const char *		ifname,		/* Device name */
	   int			request,	/* WE ID */
	   struct iwreq *	pwrq)		/* Fixed part of the request */
{
  int	ifindex = iw_get_ifindex(skfd, ifname);
  if(ifindex < 0)
    return(-1);
  return(iw_rtnetlink_do(&iw_rth, ifindex, request, &(pwrq->u)));
}

